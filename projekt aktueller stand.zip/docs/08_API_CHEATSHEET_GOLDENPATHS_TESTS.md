# 08 – API Cheatsheet, Golden Paths, Parser‑Fuzzer, v1‑Minimal Scope
(See repository version for full examples.)
- Cheatsheet: system/power/ui/renderer/time/net.wifi/radio.lora/config/app.
- Golden Paths: Boot→App→Brightness; LoRa RX/TX with id=.
- Parser-Fuzzer plan; v1 minimal endpoints & DoD.
