// GPT: Vorbereitender Stub für spätere Implementierung (von Andi gewünscht)
#pragma once
#include <Arduino.h>

namespace svc { namespace power {

void init();   // orchestriert PMU-Start u. künftige power.* events

} } // namespace svc::power
