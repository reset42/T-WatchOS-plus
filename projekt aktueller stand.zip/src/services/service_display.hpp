// GPT: Vorbereitender Stub für spätere Implementierung (von Andi gewünscht)
#pragma once
#include <Arduino.h>

namespace svc { namespace display {

void init();   // orchestriert Display-Start und ui.* / backlight.* / display.* Events

} } // namespace svc::display
