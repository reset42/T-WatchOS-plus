// src/services/service_power.cpp
// Power-Service (gehärtet, ohne Workaround):
//  - Intent-Handling wie gehabt (Backlight-Rampe macht Display-Service)
//  - ECHTER Light-Sleep mit GPIO-Wake (levelbasiert) + optionalem Timer-Wake
//  - AXP2101 PMU-INT „stuck low“: nur diagnostizieren (dump+clear), NICHT maskieren
//  - Leitungs-Check + ausführliches Logging (pre/post), Wake-Cause-Heuristik
//
// Beibehaltener Bus-Surface:
//   • power.intent target=ready|standby|lightsleep|deepsleep origin=...
//   • wake.user_btn / wake.rtc / wake.lora_dio1 / wake.touch_lightsleep
//   • power.sleep.autowake_ms: ms>0 → Timer-Wake zusätzlich
//
// Abhängigkeiten: core/bus.hpp, Arduino (millis/delay), esp_sleep.h, driver/gpio.h

#include "service_power.hpp"

#include <Arduino.h>
#include "../core/bus.hpp"

#include "driver/gpio.h"
#include "esp_sleep.h"

namespace svc { namespace power {

// -----------------------------------------------------------------------------
// Pin-Mapping (T-Watch S3)
//   AXP2101 INT  -> GPIO21 (active-LOW, open-drain)
//   PCF8563 INT  -> GPIO17 (active-LOW)
//   SX1262 DIO1  -> GPIO9  (active-HIGH)
//   FT6336U INT  -> GPIO16 (active-LOW), nur falls touch_lightsleep=on
static constexpr gpio_num_t PIN_PMU_INT   = GPIO_NUM_21;
static constexpr gpio_num_t PIN_RTC_INT   = GPIO_NUM_17;
static constexpr gpio_num_t PIN_LORA_DIO1 = GPIO_NUM_9;
static constexpr gpio_num_t PIN_TOUCH_INT = GPIO_NUM_16;

// -----------------------------------------------------------------------------
// Wake-Policy (per Events aus user.ini/dev.ini)
static volatile bool s_wake_user_btn      = true;
static volatile bool s_wake_rtc           = true;
static volatile bool s_wake_lora_dio1     = true;
static volatile bool s_wake_touch_ls      = false; // default off

// Optionaler Auto-Wake Timer (ms). 0 = aus.
static volatile uint32_t s_autowake_ms    = 0;

// -----------------------------------------------------------------------------
// Trace-Helfer
static inline void TRACE(const char* topic, const String& msg) {
  bus::emit_sticky(String(topic), msg);
}
static inline void TRACE_WAKE_KV(const char* key, int v) {
  bus::emit_sticky("trace.svc.power.wake", String(key) + "=" + String(v));
}

// -----------------------------------------------------------------------------
// KV-Parsing (robust gegen "key=value"-Args)
static inline String kv_value(const String& v) {
  int p = v.indexOf('=');
  return (p >= 0) ? v.substring(p + 1) : v;
}
static inline bool parse_onoff(const String& v) {
  String x = kv_value(v); x.toLowerCase();
  return (x == "on" || x == "1" || x == "true");
}
static inline uint32_t parse_u32ms(const String& v) {
  String x = kv_value(v);
  return (uint32_t) x.toInt();
}

// -----------------------------------------------------------------------------
// GPIO-helpers

static void cfg_pull(gpio_num_t pin, bool pullup, bool pulldown) {
  gpio_set_direction(pin, GPIO_MODE_INPUT);
  if (pullup) {
    gpio_set_pull_mode(pin, GPIO_PULLUP_ONLY);
  } else if (pulldown) {
    gpio_set_pull_mode(pin, GPIO_PULLDOWN_ONLY);
  } else {
    gpio_set_pull_mode(pin, GPIO_FLOATING);
  }
}
static inline int read_level(gpio_num_t pin) { return gpio_get_level(pin); }

static void wake_enable_pin(gpio_num_t pin, bool level_high_active) {
  gpio_wakeup_enable(pin, level_high_active ? GPIO_INTR_HIGH_LEVEL
                                            : GPIO_INTR_LOW_LEVEL);
}
static void wake_disable_pin(gpio_num_t pin) {
  gpio_wakeup_disable(pin);
}

// -----------------------------------------------------------------------------
// Vorbereitungen + Leitungs-Check mit AXP2101-IRQ dump/clear (ohne Maskieren)
struct WakePlan {
  bool use_user_btn;
  bool use_rtc;
  bool use_lora;
  bool use_touch;
  int  pmu_lvl, rtc_lvl, lora_lvl, touch_lvl;
};

static void enable_timer_if_configured() {
  uint32_t ms = s_autowake_ms;
  if (ms > 0) {
    esp_sleep_enable_timer_wakeup((uint64_t)ms * 1000ULL);
    TRACE("trace.svc.power.sleep", String("autowake_ms=") + String(ms));
  }
}

static bool make_wake_plan(WakePlan& plan) {
  // Start mit aktueller Policy
  plan.use_user_btn = s_wake_user_btn;
  plan.use_rtc      = s_wake_rtc;
  plan.use_lora     = s_wake_lora_dio1;
  plan.use_touch    = s_wake_touch_ls;

  // Pulls entsprechend Polarität
  if (plan.use_user_btn) { cfg_pull(PIN_PMU_INT,   true /*up*/,  false/*down*/); }
  if (plan.use_rtc)      { cfg_pull(PIN_RTC_INT,   true /*up*/,  false/*down*/); }
  if (plan.use_lora)     { cfg_pull(PIN_LORA_DIO1, false/*up*/,  true /*down*/); }
  if (plan.use_touch)    { cfg_pull(PIN_TOUCH_INT, true /*up*/,  false/*down*/); }

  // Read Pegel
  plan.pmu_lvl   = read_level(PIN_PMU_INT);
  plan.rtc_lvl   = read_level(PIN_RTC_INT);
  plan.lora_lvl  = read_level(PIN_LORA_DIO1);
  plan.touch_lvl = read_level(PIN_TOUCH_INT);

  TRACE("trace.svc.power.sleep.lines",
        String("pmu=")   + plan.pmu_lvl   +
        " rtc="          + plan.rtc_lvl   +
        " lora="         + plan.lora_lvl  +
        " touch="        + plan.touch_lvl);

  // Sonderfall: AXP2101 INT hängt LOW → IRQ-Status dumpen + löschen, Level erneut prüfen
  if (plan.use_user_btn && plan.pmu_lvl == 0) {
    TRACE("trace.svc.power.sleep", "pmu_irq=latched -> dump+clear");
    bus::emit_sticky("power.axp.irq", "op=dump");
    delay(2);
    bus::emit_sticky("power.axp.irq", "op=clear_all");
    delay(2);
    plan.pmu_lvl = read_level(PIN_PMU_INT);
    TRACE("trace.svc.power.sleep", String("pmu_irq after_clear lvl=") + String(plan.pmu_lvl));
    // Kein Maskieren mehr! Ursache wird separat analysiert.
  }

  // Wake-Enable je nach Policy
  if (plan.use_user_btn) wake_enable_pin(PIN_PMU_INT,   false/*LOW active*/);
  if (plan.use_rtc)      wake_enable_pin(PIN_RTC_INT,   false/*LOW active*/);
  if (plan.use_lora)     wake_enable_pin(PIN_LORA_DIO1, true /*HIGH active*/);
  if (plan.use_touch)    wake_enable_pin(PIN_TOUCH_INT, false/*LOW active*/);

  // Global GPIO-Wake aktivieren
  esp_sleep_enable_gpio_wakeup();

  // Entscheidungslogik:
  // a) Wenn Timer konfiguriert (s_autowake_ms>0) → darf immer schlafen, auch wenn alle GPIOs „aktiv“ sind
  // b) Sonst: mind. eine erlaubte Quelle muss aktuell INAKTIV sein (um Sofort-Wake zu vermeiden)
  bool timer_ok = (s_autowake_ms > 0);

  auto any_gpio_enabled =
      plan.use_user_btn || plan.use_rtc || plan.use_lora || plan.use_touch;

  if (!any_gpio_enabled && !timer_ok) {
    TRACE("trace.svc.power.sleep", "skip=lightsleep reason=no_wake_source_enabled");
    return false;
  }

  if (!timer_ok) {
    bool has_inactive_ready = false;
    if (plan.use_user_btn && (plan.pmu_lvl   != 0)) has_inactive_ready = true; // active LOW → inaktiv wenn 1
    if (plan.use_rtc      && (plan.rtc_lvl   != 0)) has_inactive_ready = true; // active LOW → inaktiv wenn 1
    if (plan.use_lora     && (plan.lora_lvl  == 0)) has_inactive_ready = true; // active HIGH → inaktiv wenn 0
    if (plan.use_touch    && (plan.touch_lvl != 0)) has_inactive_ready = true; // active LOW → inaktiv wenn 1
    if (!has_inactive_ready) {
      TRACE("trace.svc.power.sleep", "skip=lightsleep reason=active_wake_line_present");
      return false;
    }
  }

  return true;
}

static void cleanup_wake_pins() {
  wake_disable_pin(PIN_PMU_INT);
  wake_disable_pin(PIN_RTC_INT);
  wake_disable_pin(PIN_LORA_DIO1);
  wake_disable_pin(PIN_TOUCH_INT);
}

// -----------------------------------------------------------------------------
// Wake-Cause-Logging (GPIO/Timer)
static void log_wake_cause_after_resume(uint32_t slept_ms, const WakePlan& plan_before) {
  esp_sleep_wakeup_cause_t cause = esp_sleep_get_wakeup_cause();

  String msg = String("resume cause=");
  switch (cause) {
    case ESP_SLEEP_WAKEUP_GPIO:      msg += "gpio"; break;
    case ESP_SLEEP_WAKEUP_TIMER:     msg += "timer"; break;
    case ESP_SLEEP_WAKEUP_UNDEFINED: msg += "undefined"; break;
    default:                         msg += "other"; break;
  }
  msg += " slept_ms=" + String(slept_ms);

  // Pegel erneut einlesen für Heuristik
  int pmu   = read_level(PIN_PMU_INT);
  int rtc   = read_level(PIN_RTC_INT);
  int lora  = read_level(PIN_LORA_DIO1);
  int touch = read_level(PIN_TOUCH_INT);

  String by = "unknown";
  if (cause == ESP_SLEEP_WAKEUP_GPIO) {
    if (plan_before.use_user_btn && pmu == 0)        by = "pmu_key";
    else if (plan_before.use_rtc && rtc == 0)        by = "rtc";
    else if (plan_before.use_lora && lora == 1)      by = "lora_dio1";
    else if (plan_before.use_touch && touch == 0)    by = "touch";
  } else if (cause == ESP_SLEEP_WAKEUP_TIMER) {
    by = "timer";
  }
  msg += " by=" + by;

  TRACE("trace.svc.power.sleep", msg);
}

// -----------------------------------------------------------------------------
// Intent-Handling

static void handle_intent(const String& kv) {
  // kv: "target=ready|standby|lightsleep|deepsleep origin=api"
  int i = kv.indexOf("target=");
  String target;
  if (i >= 0) {
    int s = i + 7;
    int e = kv.indexOf(' ', s);
    if (e < 0) e = kv.length();
    target = kv.substring(s, e);
  }

  if (target == "lightsleep") {
    // 0) Guard: Irgendeine Quelle (GPIO +/- Timer) erlaubt?
    if (!s_wake_user_btn && !s_wake_rtc && !s_wake_lora_dio1 && !s_wake_touch_ls && s_autowake_ms==0) {
      TRACE("trace.svc.power.sleep", "skip=lightsleep reason=no_wake_source_enabled");
      return;
    }

    // 1) Wake-Plan erstellen (inkl. AXP-IRQ dump+clear – ohne Maskieren)
    WakePlan plan{};
    if (!make_wake_plan(plan)) {
      cleanup_wake_pins();
      return;
    }

    // 2) Timer-Wake ggf. aktivieren
    enable_timer_if_configured();

    // 3) Last-Call Signale (kurz/asynchron)
    TRACE("trace.svc.power.sleep", "enter last_call=begin");
    bus::emit_sticky("sys.lastcall", "op=begin");
    bus::emit_sticky("sys.lastcall", "op=end");
    TRACE("trace.svc.power.sleep", "enter last_call=end");

    // 4) Logs flushen, bevor USB-CDC in Sleep fällt
    if (Serial) { Serial.flush(); }
    delay(5);

    // 5) ECHTER Light-Sleep
    uint32_t t0 = millis();
    esp_light_sleep_start(); // blockiert bis Wake
    uint32_t slept = millis() - t0;

    // 6) Diag nach Resume
    log_wake_cause_after_resume(slept, plan);

    // 7) Aufräumen
    cleanup_wake_pins();

    // (Kein power.intent=ready senden – der Rest des Systems bleibt im ready-Pfad.)
    return;
  }

  // Andere Ziele unverändert, nur Telemetrie:
  TRACE("trace.svc.power.apply", String("key=power.intent value=") + kv);
}

// -----------------------------------------------------------------------------
// Events (Policy/Config)

static void on_wake_evt(const String& topic, const String& value) {
  if (topic == "wake.user_btn")            { s_wake_user_btn  = parse_onoff(value); TRACE_WAKE_KV("user_btn",        s_wake_user_btn);  return; }
  if (topic == "wake.rtc")                 { s_wake_rtc       = parse_onoff(value); TRACE_WAKE_KV("rtc",             s_wake_rtc);       return; }
  if (topic == "wake.lora_dio1")           { s_wake_lora_dio1 = parse_onoff(value); TRACE_WAKE_KV("lora_dio1",       s_wake_lora_dio1); return; }
  if (topic == "wake.touch_lightsleep")    { s_wake_touch_ls  = parse_onoff(value); TRACE_WAKE_KV("touch_lightsleep",s_wake_touch_ls);  return; }
  if (topic == "power.sleep.autowake_ms")  {
    s_autowake_ms = parse_u32ms(value);
    TRACE("trace.svc.power.sleep", String("cfg autowake_ms=")+String(s_autowake_ms));
    return;
  }
}

// -----------------------------------------------------------------------------
// Init

void init() {
  // Policies
  bus::subscribe("wake.*", on_wake_evt);

  
  // Subscribe Autowake Timer (ms)
  bus::subscribe("power.sleep.autowake_ms", on_wake_evt);
// Power-Intents
  bus::subscribe("power.intent",
    [](const String& /*topic*/, const String& kv){
      handle_intent(kv);
    });

  // Start-Trace der Policy
  TRACE_WAKE_KV("user_btn",        s_wake_user_btn ? 1 : 0);
  TRACE_WAKE_KV("rtc",             s_wake_rtc ? 1 : 0);
  TRACE_WAKE_KV("lora_dio1",       s_wake_lora_dio1 ? 1 : 0);
  TRACE_WAKE_KV("touch_lightsleep",s_wake_touch_ls ? 1 : 0);
}

} } // namespace svc::power
