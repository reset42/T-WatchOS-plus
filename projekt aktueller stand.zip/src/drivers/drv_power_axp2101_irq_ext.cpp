// drv_power_axp2101_irq_ext.cpp
// Zusatzmodul nur für erweiterte AXP2101-IRQ-Logs und -Befehle.
// Topics:
//   emit power.axp.irq op=enable_all value=on|off
//   emit power.axp.irq op=clear_all
//   emit power.axp.irq op=dump
//
// Logs:
//   trace.drv.power.irq.en_all
//   trace.drv.power.irq.dump
//   trace.drv.power.irq.before_clear
//   trace.drv.power.irq.after_clear

#include <Arduino.h>
#include <Wire.h>
#include "../core/bus.hpp"
#include "driver/gpio.h"

namespace drv { namespace axp2101_irq_ext {

static constexpr gpio_num_t PIN_PMU_INT = GPIO_NUM_21; // AXP2101 INT pin (OD, active-LOW)

#define AXP2101_I2C_ADDR  0x34

// Register laut Datenblatt / Referenz-Implementierung
#define REG_IRQ_EN1  0x40
#define REG_IRQ_EN2  0x41
#define REG_IRQ_EN3  0x42
#define REG_IRQ_ST1  0x48
#define REG_IRQ_ST2  0x49
#define REG_IRQ_ST3  0x4A

// --- Backend wählen ---
// 1 = Wire (default), 0 = Platzhalter für projektspezifische I2C-Funktionen
#define AXP2101_IRQ_EXT_USE_WIRE 1

#if AXP2101_IRQ_EXT_USE_WIRE

static bool i2c_read_u8(uint8_t reg, uint8_t& out)
{
  Wire.beginTransmission(AXP2101_I2C_ADDR);
  Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((int)AXP2101_I2C_ADDR, 1) != 1) return false;
  out = Wire.read();
  return true;
}

static bool i2c_write_u8(uint8_t reg, uint8_t val)
{
  Wire.beginTransmission(AXP2101_I2C_ADDR);
  Wire.write(reg);
  Wire.write(val);
  return Wire.endTransmission(true) == 0;
}

#else
// ==== Falls du eigenes I2C-Backend hast, ersetze diese beiden Funktionen ====
static bool i2c_read_u8(uint8_t reg, uint8_t& out)
{
  // TODO: projekt-spezifisch implementieren
  (void)reg; (void)out;
  return false;
}
static bool i2c_write_u8(uint8_t reg, uint8_t val)
{
  // TODO: projekt-spezifisch implementieren
  (void)reg; (void)val;
  return false;
}
#endif

static inline void log_regs(const char* tag,
                            uint8_t e1,uint8_t e2,uint8_t e3,
                            uint8_t s1,uint8_t s2,uint8_t s3)
{
  bus::emit_sticky(tag,
    String("en40=0x") + String(e1,16) +
    " en41=0x" + String(e2,16) +
    " en42=0x" + String(e3,16) +
    " st48=0x" + String(s1,16) +
    " st49=0x" + String(s2,16) +
    " st4A=0x" + String(s3,16));
}

static void read_all(uint8_t& e1,uint8_t& e2,uint8_t& e3,
                     uint8_t& s1,uint8_t& s2,uint8_t& s3)
{
  uint8_t tmp;
  i2c_read_u8(REG_IRQ_EN1, tmp); e1 = tmp;
  i2c_read_u8(REG_IRQ_EN2, tmp); e2 = tmp;
  i2c_read_u8(REG_IRQ_EN3, tmp); e3 = tmp;
  i2c_read_u8(REG_IRQ_ST1, tmp); s1 = tmp;
  i2c_read_u8(REG_IRQ_ST2, tmp); s2 = tmp;
  i2c_read_u8(REG_IRQ_ST3, tmp); s3 = tmp;
}

static void irq_dump()
{
  uint8_t e1,e2,e3,s1,s2,s3;
  read_all(e1,e2,e3,s1,s2,s3);
  log_regs("trace.drv.power.irq.dump", e1,e2,e3,s1,s2,s3);
}

static void irq_clear_all()
{
  // vorher
  uint8_t e1,e2,e3,s1,s2,s3;
  read_all(e1,e2,e3,s1,s2,s3);
  log_regs("trace.drv.power.irq.before_clear", e1,e2,e3,s1,s2,s3);

  // Write-1-to-Clear; falls 0 gelesen -> 0xFF (brutaler Clear), wie besprochen
  i2c_write_u8(REG_IRQ_ST1, 0xFF);
  i2c_write_u8(REG_IRQ_ST2, 0xFF);
  i2c_write_u8(REG_IRQ_ST3, 0xFF);
  delay(2);

  // nachher
  read_all(e1,e2,e3,s1,s2,s3);
  log_regs("trace.drv.power.irq.after_clear", e1,e2,e3,s1,s2,s3);
  // INT line level after clear
  int lvl = gpio_get_level(PIN_PMU_INT);
  bus::emit_sticky("trace.drv.power.irq.int_level", String("pmu_int_gpio21=")+String(lvl));
}

static void irq_enable_all(bool on)
{
  i2c_write_u8(REG_IRQ_EN1, on ? 0xFF : 0x00);
  i2c_write_u8(REG_IRQ_EN2, on ? 0xFF : 0x00);
  i2c_write_u8(REG_IRQ_EN3, on ? 0xFF : 0x00);
  delay(1);
  irq_dump(); // loggt als trace.drv.power.irq.dump
  bus::emit_sticky("trace.drv.power.irq.en_all", String("on=") + (on ? "1" : "0"));
}

// Bus-Hook
static void on_bus_cmd(const String& /*topic*/, const String& args)
{
  if (args.indexOf("op=dump") >= 0) {
    irq_dump();
    return;
  }
  if (args.indexOf("op=clear_all") >= 0) {
    irq_clear_all();
    return;
  }
  if (args.indexOf("op=enable_all") >= 0) {
    bool on = (args.indexOf("value=on") >= 0 || args.indexOf("value=1") >= 0 || args.indexOf("value=true") >= 0);
    irq_enable_all(on);
    return;
  }
}

// Statischer Konstruktor: registriert den Subscriber früh.
// (Falls du es lieber explizit hast, exportiere init() und rufe sie in deinem main auf.)
struct AutoHook {
  AutoHook() {
    bus::subscribe("power.axp.irq", on_bus_cmd);
  }
} s_autohook;

} } // namespace drv::axp2101_irq_ext
