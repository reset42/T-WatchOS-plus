// GPT: Vorbereitender Stub für spätere Implementierung (von Andi gewünscht)
#pragma once
#include <Arduino.h>

namespace drv { namespace touch_ft6236u {

void init();
void apply_kv(const String& key, const String& value);

} } // namespace drv::touch_ft6236u
